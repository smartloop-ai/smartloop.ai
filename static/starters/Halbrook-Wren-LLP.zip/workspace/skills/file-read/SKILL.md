---
name: file-read
description: Use when the user wants to read, view, or inspect the contents of a file.
---

read the file at the given path and return its content