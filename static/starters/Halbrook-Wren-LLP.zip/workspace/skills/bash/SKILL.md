---
name: bash
description: Use when the user wants to run a shell command, execute a script, or perform system operations.
---

execute the shell command on the host machine