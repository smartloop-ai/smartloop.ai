---
name: file-write
description: Use when the user wants to write, save, or create a file with specific content.
---

write content to a file at the given path